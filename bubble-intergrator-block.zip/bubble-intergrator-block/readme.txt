=== Bubble Integrator Block ===
Tags: UseBubbles, Video, Embed
Requires at least: 6.7
Tested up to: 7.1.3
Stable tag: 1.1.8
Requires PHP: 8.0

Allows you to add usebubbles.com videos embedded on your WordPress sites easily and quickly
== Description ==

Allows you to add usebubbles.com videos embedded on your WordPress sites easily and quickly

== Installation ==

1. Upload the `bubble-intergrator-block` folder to the `/wp-content/plugins/` directory.
2. Go to a Guttenberg page you will now have a new block.
3. use the configurator to modify the use bubbles embed

== Frequently Asked Questions ==

== Changelog ==
= 1.1.8 16 October 2026 =
Updated: UUPD Dependency Updated to Version 2.1 Stable
Updated: Deploy Methodology

= 1.1.7 July 2026 =
Updated: UUPD Dependency Updated to Version 2.0 Stable


= 1.1.6 23 March 2026 =
Update: Updater to 2.0-Alpha
Update: Compatibility 


= 1.1.5 12 August 2025 =
New: Deploy Methodology 
New: Production Test - New deploy.sh 

= 1.1.4 07 Aug 2025 =
Fix: Bug Fixes

= 1.1.3 27 July 2025 =
Fix: Comment out WP Icon Filter which is causing issues in latest MainWP

= 1.1.2 27 July 2025 =
New: Main WP Icon Filter

= 1.1.1 27 July 2025 =
New: Prepare Future Support for Preleases
New: Updated UUPD to 1.3.0

= 1.1 =
Prep for Automatic Updates and Push version numbers

= 1.0 =
Initial Release